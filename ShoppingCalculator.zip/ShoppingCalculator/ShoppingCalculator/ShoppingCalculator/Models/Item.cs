﻿namespace ShoppingCalculator.Models
{
    public class Item
    {
        public string ItemName { get; set; }
        public double ItemUnitPrice { get; set; }
        public double ItemQuantity { get; set; }
        public double ItemTotal => ItemUnitPrice * ItemQuantity;
    }
}

﻿using System;
using System.Linq;
using System.Collections.ObjectModel;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using ShoppingCalculator.Models;

namespace ShoppingCalculator
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CalculatorPage : ContentPage
    {
        ObservableCollection<Item> Items;

        public CalculatorPage()
        {
            InitializeComponent();

            Items = new ObservableCollection<Item>();
            itemListView.ItemsSource = Items;
        }

        private async void addItemButton_Clicked(object sender, EventArgs e)
        {
            Item item = new Item()
            {
                ItemName = itemNameEntry.Text,
                ItemUnitPrice = double.Parse(itemUnitPriceEntry.Text),
                ItemQuantity = double.Parse(itemQuantityEntry.Text)
            };

            Items.Add(item);

            double total = Items.Sum(x => x.ItemTotal);
            totalLabel.Text = total.ToString("C2");

            await DisplayAlert("Shopping List", "Item added", "OK");

            itemNameEntry.Text = string.Empty;
            itemUnitPriceEntry.Text = string.Empty;
            itemQuantityEntry.Text = string.Empty;
        }
    }
}